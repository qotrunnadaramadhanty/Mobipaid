<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Login please wait</name>
   <tag></tag>
   <elementGuidId>0e730744-288a-4c08-ac6f-9d675636f06e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.col-md-12.col-xs-12.merchant-login-text.mrgn-bot-vs</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='login-form']/div[8]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c4ab5a8d-3464-41a7-9613-5aa809b925d1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-md-12 col-xs-12 merchant-login-text mrgn-bot-vs</value>
      <webElementGuid>000ffbc4-46fa-4e7f-a67f-b610ec35d32e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                Login please wait 
              </value>
      <webElementGuid>e4f65b43-a31f-4872-a4cf-dcd7f291549c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;login-form&quot;)/div[@class=&quot;col-md-12 col-xs-12 merchant-login-text mrgn-bot-vs&quot;]</value>
      <webElementGuid>7f940a26-9175-43ab-acc2-33f0e774274f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='login-form']/div[8]</value>
      <webElementGuid>97ce26bf-4aa4-4ec4-92f4-6d1a5d74ff48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forgot password?'])[1]/following::div[1]</value>
      <webElementGuid>bb145509-b4ae-4a88-941c-be0c9149f854</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MERCHANT LOGIN'])[1]/following::div[7]</value>
      <webElementGuid>d2d59638-5d1c-49df-890d-c0c5f5f2bfc7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div[8]</value>
      <webElementGuid>fd9781c2-ce90-491a-a646-c5df2360ba01</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                Login please wait 
              ' or . = '
                Login please wait 
              ')]</value>
      <webElementGuid>7a95b4ee-d806-480a-825a-052e5d9bbb78</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
