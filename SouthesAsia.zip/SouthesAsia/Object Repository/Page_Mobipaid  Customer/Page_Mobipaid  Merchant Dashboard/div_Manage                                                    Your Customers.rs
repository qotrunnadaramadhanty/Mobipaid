<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Manage                                                    Your Customers</name>
   <tag></tag>
   <elementGuidId>848bcf81-59e9-4456-9e1d-f95940ea9c3b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.ncard.manage-customers</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='manageCustomer_card']/a/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>d2f66372-251b-4473-8296-6e46568a3241</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ncard manage-customers</value>
      <webElementGuid>43661057-b928-4b70-936d-107f75974dfc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    Manage
                                                    Your Customers
                                                    
                                                        
                                                    
                                                
                                            
                                        </value>
      <webElementGuid>15dc3600-b903-4597-8773-bec3b6c774a8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;manageCustomer_card&quot;)/a[@class=&quot;secondary-dashboard-cta&quot;]/div[@class=&quot;ncard manage-customers&quot;]</value>
      <webElementGuid>58dcc6d7-69cb-4f00-a43c-4e7efaebb7d1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='manageCustomer_card']/a/div</value>
      <webElementGuid>1e9827a0-c131-49f1-a0fd-7cf504233801</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='USD 0'])[1]/following::div[2]</value>
      <webElementGuid>1465e15b-be76-4db5-982e-de5801e7086e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='In :'])[1]/following::div[3]</value>
      <webElementGuid>bc97b60f-29d8-4451-85cc-a274cb8b35df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/a/div</value>
      <webElementGuid>5a1a8a6c-cefc-4be3-9df7-c42733b619f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    Manage
                                                    Your Customers
                                                    
                                                        
                                                    
                                                
                                            
                                        ' or . = '
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    Manage
                                                    Your Customers
                                                    
                                                        
                                                    
                                                
                                            
                                        ')]</value>
      <webElementGuid>4a79f8f3-eb90-4a35-97eb-61a3c274be26</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
