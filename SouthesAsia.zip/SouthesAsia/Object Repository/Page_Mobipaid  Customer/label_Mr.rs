<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Mr</name>
   <tag></tag>
   <elementGuidId>f711f5f5-af1f-4e38-b1c9-421017b7a340</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.salutation-selection.nw-style > label.btn.btn-sm-pad.btn-outline-blue.active</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='addCustomers']/div/div/div/div[3]/div[3]/div/div/div/div/label[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>f9e70651-6990-4c2c-9c00-36daff8f57ee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-sm-pad btn-outline-blue active</value>
      <webElementGuid>9b2465c8-5370-44fb-87f9-debdebfe4867</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                     Mr.                </value>
      <webElementGuid>cc5c9a3c-9206-47d4-9eea-20bcae215431</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;addCustomers&quot;)/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content mp-modalbox&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;main-modal-content&quot;]/div[@class=&quot;customer-field&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12&quot;]/div[@class=&quot;cust-modalForm field-group&quot;]/div[@class=&quot;salutation-selection nw-style&quot;]/label[@class=&quot;btn btn-sm-pad btn-outline-blue active&quot;]</value>
      <webElementGuid>ad3c0735-ab2c-4ad8-840f-0375e016053b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='addCustomers']/div/div/div/div[3]/div[3]/div/div/div/div/label[2]</value>
      <webElementGuid>2cef5abd-4c0e-4687-b950-362300b0df55</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Salutation'])[1]/following::label[2]</value>
      <webElementGuid>f0c8b1cd-da5a-4e08-b79b-be289be1aae8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Mr.']/parent::*</value>
      <webElementGuid>0bef191f-eb4d-4c15-9aa3-1ae44fe6554b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[3]/div/div/div/div/label[2]</value>
      <webElementGuid>1b3742dd-67b7-4c0f-be42-f431c0bc304c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
                     Mr.                ' or . = '
                     Mr.                ')]</value>
      <webElementGuid>29f0d539-f34b-4738-b804-88359d90e673</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
